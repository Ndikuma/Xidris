"""
Todo App created with flet
Some notes:
   1. This is a full app=> UI + Database Function
   2. Slighlty longer Video but with more explainations
"""
#modules
import flet as ft
from flet import *
from datetime import datetime as d
import sqlite3

# Let 's Create  The form class first so we can get some data
class Database():
    def ConnectToDatabase():
        try:
            db=sqlite3.connect('todo.db')
            c=db.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS  tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,Task VARCHAR(255) NOT NULL,Date VARCHAR(255)NOT NULL)''')
            return db
        except Exception as e:
            print(e)
    def ReadDatabase(db):
        c=db.cursor   ()
        c.execute("SELECT Task,Date FROM tasks")
        records=c.fetchall()
        return records
    def InsertDatabase(db,values):
        c=db.cursor()
        c.execute("INSERT INTO tasks (Task,Date) VALUES(?,?) ",values)
        db.commit()
    def DeleteDatabase(db,value):
        c=db.cursor()
        c.execute("DELETE FROM tasks WHERE Task=?",value)
        db.commit() 
    def UpdateDatabase(db,value):
        c=db.cursor()
        c.execute("UPDATE tasks SET Task=?",value) 
        db.commit()
class FormContainer(UserControl):
    # at this point , we can pass in a function from the main() so we can expand
    # go back to the FormContainer() and add argument as such ...
    def __init__(self,func):
        self.func=func
        super().__init__()
        
    def build(self):
        return Container(
            width=280,
            height=88,
            bgcolor="bluegrey500",
            opacity=0, # change late
            border_radius=40,
            margin=margin.only(left=-20,right=-20),
            animate=animation.Animation(400,"decelerate"),
            animate_opacity=200,
            padding=padding.only(top=45,bottom=45),
            content=Column(
                horizontal_alignment=CrossAxisAlignment.CENTER,
                controls=[
                    TextField(
                      height=48,
                      width=255,
                      filled=True, 
                      color="black",
                      text_size=12,
                      border_color="transparent",
                      hint_text="Description ...", 
                      hint_style=TextStyle(
                          size=11,color="black",
                      )
                    ),
                    IconButton(
                        content=Text("Add Task"),
                        width=100,
                        height=44,
                        on_click=self.func,
                        style=ButtonStyle(
                            bgcolor= "black",
                            shape= RoundedRectangleBorder(radius=8),
                                  
                            ),
                    ),
                ],
            ),
            
        )

#now we need a class to generate a task when the user adds one
class CreateTask(UserControl):
    def __init__(self,task:str ,date:str,func1,func2):
        #create two argments so we can pass in the delete fonction and edit function
        #when we create an instance of this
        self.task=task
        self.date=date
        self.func1=func1
        self.func2=func2
        super().__init__()
    
    def TaskDeleteEdit(self,name,color,func):
        return IconButton(
            icon=name,
            width=30,
            icon_size=18,
            icon_color=color,
            opacity=0,
            animate_opacity=200,
            on_click=lambda e: func(self.GetContainerInstance())# change later 
        )
    # we need a final thing from here and that is the instance itself
    #we need the instance identifier so that we can delete it needs to be delete
    def GetContainerInstance(self):
        return self # we return the self instance
    # to use it e need to keep it in our delete and edit iconButtons

    def ShowIcons(self,e):
        
        if e.data=='true':
            #these are index's of each icon
            (e.control.content.controls[1].controls[0].opacity,
             e.control.content.controls[1].controls[1].opacity)=(1,1)
            e.control.content.update()
        else:
            (e.control.content.controls[1].controls[0].opacity,
             e.control.content.controls[1].controls[1].opacity)=(0,0)
            e.control.content.update()
            
        
    def build(self):
        return Container(
           
            width=280,
            height=60,
            border=border.all(0.85,"white54"),
            border_radius=8,
            #let 's show the icons when we hover over them ...
            on_hover=lambda e: self.ShowIcons(e), 
            clip_behavior=ClipBehavior.HARD_EDGE,
            padding=10,
            content=Row(
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    Column(
                        spacing=1,
                        alignment=MainAxisAlignment.CENTER,
                        controls=[
                            Text(value=self.task,size=16),
                            Text(value=self.date ,size=9,color='white54'),
                        ],
                    ),
                    #icons Delete and Edit
                    Row(
                        spacing=0,
                        alignment=MainAxisAlignment.CENTER,
                        controls=[
                            self.TaskDeleteEdit(icons.DELETE_ROUNDED,"red500",self.func1),
                            self.TaskDeleteEdit(icons.EDIT_ROUNDED,"white70",self.func2),
                            
                        ]
                    )
                    
                ] 
        ))
        
        
        

def main(page: Page):
    page.horizontal_alignment='center'
    page.vertical_alignment='center'
    
    def AddTaskToScreen(e):
        # now everytime the use adds a task we need to fetch the data and output it to the main column
        #there are to data we need the task + date
        datetime= d.now().strftime("%b %d ,%Y %I: %M") 
        db=Database.ConnectToDatabase()
        Database.InsertDatabase(db,(form.content.controls[0].value, datetime))
        db.close()
        #now recell that we set the form container to form variable we can use this to see if there 's any content in textField 
        if form.content.controls[0].value: # this checks the textfield 's value
            _main_column.controls.append(
               #here , we can create a instance to createTask() class '''
               CreateTask(
                   #now it take two argments
                   form.content.controls[0].value,
                   datetime,
                   #now the instance takes two more argments when colled...
                   DeleteFunction,
                   EditFunction,
                   
               ) 
            )
            _main_column.update()
            #we can recall the show/hide function for the form hire
            CreateToDoTask(e)
        else:
            db.close()
            pass
    def DeleteFunction(e):
        #when  we want to delete recall that these instance are in a list=>
        #so that means we can simply romove them when we want to
      #so the instance is passed on as e
        _main_column.controls.remove(e) # e is the instance itself
        _main_column.update()
      
    def EditFunction(e):
        #the update needs a little bit more work ..
        # we weant to update form the for ,so we need to pass whatever the user had foem the instance
        #back to the form then changr the function and pass it back again .,..
        form.height ,form.opacity= 200,1 #show the form
        (form.content.controls[0].value,
         # here we are changing the botton function and name ..
         # we need to chang it form add task to Update and so on
         form.content.controls[1].content.value,
         form.content.controls[1].on_click,
         )=(
             e.controls[0].content.controls[0].controls[0].value, #this is the instance value of the task
             "Update", 
             lambda _: FinalizeUpdate(e),
             
         )
        form.update()
    
         # once the use edits, we need to send the correct data back
    def FinalizeUpdate(e):
        e.controls[0].content.controls[0].controls[0].value=form.content.controls[0].value,
        e.controls[0].content.update()
        CreateToDoTask(e)
 #function to show/hiden form container
    def CreateToDoTask(e):
        # we can click add iconButton
        if form.height !=200:
            form.height,form.opacity=200,1
            form.update()
        else:
            form.height ,form.opacity=80,0
            form.content.controls[0].value=None
            form.content.controls[1].content.value="Add text"
            form.content.controls[1].on_click= lambda e:AddTaskToScreen(e)
            form.update()
    
    
    _main_column= Column(
        scroll="hidden",
        expand=True,
        alignment=MainAxisAlignment.START,
        controls=[
            Row(
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    #Some title Stuff
                    Text("To-Do App",size= 18,weight="bold"),
                    IconButton(icons.ADD_CIRCLE_ROUNDED,
                               icon_size=18,
                               on_click=lambda e: CreateToDoTask(e),
                               ),
                ],
            ),
            
            Divider(height=8,color="white24")
        ]
    )
    # set up some bg and main container
    # the general UI will copy that of a mobile app
    page.add(
      #This is bg Container
      Container(
          width=1500,
          height=800,
          margin=-10,
          bgcolor="bluegrey900",
          alignment=alignment.center,
          content=Row(
                 alignment=MainAxisAlignment.CENTER,
                 vertical_alignment=CrossAxisAlignment.CENTER,
                 controls=[
                     #Main container
                     Container(
                         width=280,
                         height=550,
                         bgcolor="#0f0f0f",
                         border_radius=40,
                         border=border.all(0.5,"white"),
                         padding=padding.only(top=35,left=20 ,right=20),
                         clip_behavior=ClipBehavior.HARD_EDGE ,# clip contents to container
                         content=Column(
                               alignment=MainAxisAlignment.CENTER,
                               expand=True,
                               controls=[
                                   #main column here...
                                   _main_column,
                                   #Form class here .
                                   # pass in the argument for the form class here
                                   FormContainer(lambda e:AddTaskToScreen(e)),
                               ]
                         ) 
                         
                     )
                 ]
                 
              
          )
            
        ) 
    )
    page.update()
    #the form container index is as follows .we can set the long element index as 
    #variable so it can be colled faster and easier.
    form=page.controls[0].content.controls[0 ].content.controls[1].controls[0]
    # now we can  call form whenever we want to do something with it ....
    db=Database.ConnectToDatabase()
    for task in Database.ReadDatabase(db):
        print(task)
    
if __name__=="__main__":
    ft.app(target=main) 